
import React, { useState } from 'react';
import { ExamQuestion } from '../types';
import { GoogleGenAI, Type } from "@google/genai";

interface ExamBuilderProps {
  onStartExam: (questions: ExamQuestion[]) => void;
}

const ExamBuilder: React.FC<ExamBuilderProps> = ({ onStartExam }) => {
  const [questions, setQuestions] = useState<ExamQuestion[]>([]);
  const [currentQ, setCurrentQ] = useState<string>('');
  const [options, setOptions] = useState<string[]>(['', '', '', '']);
  const [correctIndex, setCorrectIndex] = useState<number>(0);
  const [explanation, setExplanation] = useState<string>('');
  
  // AI Assistant State
  const [aiPrompt, setAiPrompt] = useState('');
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [showAiAssistant, setShowAiAssistant] = useState(false);

  const handleAddQuestion = () => {
    if (!currentQ || options.some(opt => !opt)) {
      alert("عيني املأ السؤال وكل الخيارات أولاً.");
      return;
    }
    
    const newQuestion: ExamQuestion = {
      question: currentQ,
      options: [...options],
      correctIndex,
      explanation: explanation || "إجابة صحيحة!"
    };

    setQuestions([...questions, newQuestion]);
    resetForm();
  };

  const resetForm = () => {
    setCurrentQ('');
    setOptions(['', '', '', '']);
    setCorrectIndex(0);
    setExplanation('');
  };

  const removeQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const handleAiAssistant = async () => {
    if (!aiPrompt) return;
    setIsAiProcessing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `ساعد المستخدم في بناء اختبار MCQ. الطلب: ${aiPrompt}. 
        إذا كان الطلب موضوعاً، ولد أسئلة عنه. 
        إذا كان الطلب نصاً، استخرج منه أسئلة.
        يجب أن يكون الرد JSON كقائمة من الأسئلة.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctIndex: { type: Type.INTEGER },
                explanation: { type: Type.STRING }
              },
              required: ["question", "options", "correctIndex", "explanation"]
            }
          }
        }
      });

      const newAiQuestions = JSON.parse(response.text);
      setQuestions([...questions, ...newAiQuestions]);
      setAiPrompt('');
      setShowAiAssistant(false);
    } catch (e) {
      alert("فشل المساعد في توليد الأسئلة عيني.");
    } finally {
      setIsAiProcessing(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* AI Assistant Toggle/Panel */}
      <div className="bg-gradient-to-r from-orange-500 to-amber-500 p-1 rounded-[2.5rem] shadow-xl">
        <div className="bg-white p-8 rounded-[2.4rem] space-y-6">
          <div className="flex justify-between items-center">
             <h3 className="text-xl font-black text-slate-800 flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center">
                  <i className="fa-solid fa-wand-magic-sparkles"></i>
                </div>
                مساعد الأسئلة الذكي
             </h3>
             <button 
               onClick={() => setShowAiAssistant(!showAiAssistant)}
               className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${showAiAssistant ? 'bg-slate-100 text-slate-500' : 'bg-orange-600 text-white shadow-lg shadow-orange-200'}`}
             >
               {showAiAssistant ? 'إغلاق المساعد' : 'اطلب من الذكاء توليد أسئلة'}
             </button>
          </div>

          {showAiAssistant && (
            <div className="space-y-4 animate-in slide-in-from-top-4">
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="مثلاً: 'اكتب لي 5 أسئلة عن مادة الأحياء الفصل الأول' أو الصق نصاً هنا لاستخراج الأسئلة منه..."
                className="w-full p-4 bg-orange-50/50 border-2 border-orange-100 focus:border-orange-500 rounded-2xl outline-none transition-all h-28 text-sm font-medium"
              />
              <button
                onClick={handleAiAssistant}
                disabled={isAiProcessing || !aiPrompt}
                className="w-full py-4 bg-orange-600 text-white rounded-2xl font-black flex items-center justify-center gap-3 hover:bg-orange-700 disabled:opacity-50 shadow-lg shadow-orange-100"
              >
                {isAiProcessing ? <i className="fa-solid fa-spinner animate-spin"></i> : <i className="fa-solid fa-bolt-lightning"></i>}
                توليد وإضافة للمسودة
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100">
        <h3 className="text-xl font-black text-slate-800 mb-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-100 text-slate-600 rounded-xl flex items-center justify-center">
            <i className="fa-solid fa-pen-to-square"></i>
          </div>
          إضافة سؤال يدوياً
        </h3>

        <div className="space-y-4">
          <textarea
            value={currentQ}
            onChange={(e) => setCurrentQ(e.target.value)}
            placeholder="اكتب سؤالك الخاص هنا..."
            className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl outline-none transition-all h-24 font-bold"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {options.map((opt, idx) => (
              <div key={idx} className="relative">
                <input
                  value={opt}
                  onChange={(e) => {
                    const newOpts = [...options];
                    newOpts[idx] = e.target.value;
                    setOptions(newOpts);
                  }}
                  placeholder={`الخيار ${idx + 1}`}
                  className={`w-full p-4 pr-12 bg-slate-50 border-2 rounded-2xl outline-none transition-all ${correctIndex === idx ? 'border-green-500 bg-green-50/30' : 'border-transparent focus:border-slate-200'}`}
                />
                <button
                  onClick={() => setCorrectIndex(idx)}
                  className={`absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${correctIndex === idx ? 'bg-green-500 border-green-500 text-white' : 'border-slate-200 text-slate-300'}`}
                >
                  {correctIndex === idx ? <i className="fa-solid fa-check text-xs"></i> : <span className="text-xs">{idx + 1}</span>}
                </button>
              </div>
            ))}
          </div>

          <button
            onClick={handleAddQuestion}
            className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-black transition-all flex items-center justify-center gap-2"
          >
            <i className="fa-solid fa-plus-circle"></i> تثبيت السؤال في القائمة
          </button>
        </div>
      </div>

      {questions.length > 0 && (
        <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100 animate-in fade-in slide-in-from-bottom-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-xl font-black text-slate-800">مسودة الامتحان</h3>
              <p className="text-xs text-slate-400 font-bold">لديك {questions.length} أسئلة جاهزة</p>
            </div>
            <button
              onClick={() => onStartExam(questions)}
              className="px-8 py-3 bg-blue-600 text-white rounded-xl font-black shadow-lg shadow-blue-200 hover:bg-blue-700 transition-all flex items-center gap-2 scale-105 active:scale-95"
            >
              <i className="fa-solid fa-play"></i> ابدأ الاختبار الآن
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
            {questions.map((q, i) => (
              <div key={i} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex justify-between items-center group hover:bg-white hover:shadow-md transition-all">
                <div className="flex items-center gap-4 overflow-hidden">
                  <span className="w-8 h-8 bg-white rounded-lg flex items-center justify-center font-black text-blue-600 text-xs shadow-sm shrink-0">{i + 1}</span>
                  <p className="font-bold text-slate-700 truncate">{q.question}</p>
                </div>
                <button onClick={() => removeQuestion(i)} className="text-slate-300 hover:text-red-500 transition-colors p-2 shrink-0">
                  <i className="fa-solid fa-trash-can"></i>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ExamBuilder;
