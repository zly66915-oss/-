
import React, { useState } from 'react';
import { ExamQuestion } from '../types';

interface ExamSystemProps {
  questions: ExamQuestion[];
  onComplete: (score: number) => void;
  onClose: () => void;
  title: string;
}

const ExamSystem: React.FC<ExamSystemProps> = ({ questions, onComplete, onClose, title }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  if (!questions || questions.length === 0) {
    return (
      <div className="fixed inset-0 z-[100] bg-slate-900/90 backdrop-blur-md flex items-center justify-center p-6">
        <div className="bg-white p-10 rounded-[3rem] text-center shadow-2xl">
          <p className="font-black text-slate-800 mb-6">عذراً، لا توجد أسئلة متوفرة حالياً.</p>
          <button onClick={onClose} className="px-8 py-3 bg-blue-600 text-white rounded-xl font-black">إغلاق</button>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIndex];

  const handleAnswer = (index: number) => {
    if (showFeedback) return;
    setSelectedOption(index);
    setShowFeedback(true);
    if (index === currentQ.correctIndex) setScore(prev => prev + 1);
  };

  const nextQuestion = () => {
    setShowFeedback(false);
    setSelectedOption(null);
    if (currentIndex < questions.length - 1) setCurrentIndex(prev => prev + 1);
    else setIsFinished(true);
  };

  if (isFinished) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="fixed inset-0 z-[100] bg-slate-900/90 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in">
        <div className="bg-white w-full max-w-xl rounded-[3rem] p-10 text-center shadow-2xl space-y-8">
          <div className="w-24 h-24 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center mx-auto text-4xl shadow-lg animate-bounce"><i className="fa-solid fa-trophy"></i></div>
          <h2 className="text-3xl font-black text-slate-800 mb-2">اكتمل الاختبار!</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-50 p-6 rounded-[2rem] border"><p className="text-[10px] font-black text-slate-400 mb-1">النتيجة</p><p className="text-4xl font-black text-blue-600">{percentage}%</p></div>
            <div className="bg-slate-50 p-6 rounded-[2rem] border"><p className="text-[10px] font-black text-slate-400 mb-1">الإجابات</p><p className="text-4xl font-black text-green-500">{score}/{questions.length}</p></div>
          </div>
          <button onClick={() => onComplete(percentage)} className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black shadow-xl">حفظ النتيجة والعودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/90 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-2xl rounded-[3rem] overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        <div className="bg-slate-50 px-8 py-6 border-b flex justify-between items-center">
          <div><h3 className="font-black text-slate-800">{title}</h3><p className="text-xs text-slate-400 font-bold">سؤال {currentIndex + 1} من {questions.length}</p></div>
          <button onClick={onClose} className="w-10 h-10 rounded-full hover:bg-red-50 text-slate-300"><i className="fa-solid fa-xmark text-lg"></i></button>
        </div>
        <div className="h-1.5 w-full bg-slate-100"><div className="h-full bg-blue-500 transition-all duration-500" style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}></div></div>
        <div className="p-10 overflow-y-auto space-y-8">
          <div className="bg-blue-50/30 p-8 rounded-[2rem] border"><h4 className="text-xl font-bold text-slate-800 leading-relaxed text-right">{currentQ.question}</h4></div>
          <div className="grid grid-cols-1 gap-3">
            {currentQ.options.map((option, idx) => (
              <button key={idx} onClick={() => handleAnswer(idx)} disabled={showFeedback} className={`p-5 rounded-2xl text-right font-bold transition-all border-2 flex items-center justify-between ${showFeedback ? idx === currentQ.correctIndex ? 'bg-green-50 border-green-500 text-green-700' : idx === selectedOption ? 'bg-red-50 border-red-500 text-red-700' : 'bg-white border-slate-100 opacity-50' : 'bg-white border-slate-100 hover:border-blue-200 hover:bg-blue-50/30'}`}>
                <span className="flex-1">{option}</span>
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 mr-4 ${showFeedback && idx === currentQ.correctIndex ? 'bg-green-500 border-green-500 text-white' : 'border-slate-200'}`}>{showFeedback && idx === currentQ.correctIndex && <i className="fa-solid fa-check text-[10px]"></i>}</div>
              </button>
            ))}
          </div>
          {showFeedback && (
            <div className="animate-in slide-in-from-top-4 duration-300 p-6 bg-slate-50 rounded-2xl border">
               <p className={`font-black text-sm mb-2 ${selectedOption === currentQ.correctIndex ? 'text-green-600' : 'text-red-600'}`}>{selectedOption === currentQ.correctIndex ? 'أحسنت!' : 'إجابة غير صحيحة'}</p>
               <p className="text-xs text-slate-600 leading-relaxed font-medium mb-6">{currentQ.explanation}</p>
               <button onClick={nextQuestion} className="w-full py-3 bg-slate-800 text-white rounded-xl font-bold flex items-center justify-center gap-2">السؤال التالي <i className="fa-solid fa-arrow-left"></i></button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExamSystem;
